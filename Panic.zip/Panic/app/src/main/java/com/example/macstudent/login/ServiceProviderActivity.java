package com.example.macstudent.login;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.database.Cursor;

import android.widget.EditText;
import android.widget.Toast;

public class ServiceProviderActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnServiceProvider;
    EditText edtServiceProvider;
    DBHelper dbHelper;
    SQLiteDatabase ParkingDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_provider);
        btnServiceProvider=findViewById(R.id.btnServiceProvider);
        edtServiceProvider=findViewById(R.id.edtServiceProvider);

        btnServiceProvider.setOnClickListener(this);
        dbHelper=new DBHelper(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==btnServiceProvider.getId())
        {
            insertData();
            Toast.makeText(this,"Service provider added successfully",Toast.LENGTH_LONG).show();
  //         Intent homeIntent=new Intent(this,HomeActivity.class);
//            startActivity(homeIntent);
        }
    }
    private void insertData()
    {
        String phoneNo=edtServiceProvider.getText().toString();
        ContentValues cv=new ContentValues();
        cv.put("PhoneNo",phoneNo);
        try
        {
            ParkingDB=dbHelper.getWritableDatabase();
            ParkingDB.insert("ServiceProvider",null,cv);
           // Log.v(ServiceProviderActivity,"service provider added");

        }catch (Exception e)
        {
           // Log.e(ServiceProviderActivity, e.getMessage());
        }
        ParkingDB.close();
    }
}

package com.example.macstudent.login;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddContactActivity extends AppCompatActivity implements View.OnClickListener {
EditText edtName;
EditText edtPhone;
EditText edtEmail;
DBHelper dbHelper;
Button btnAddContact;
    SQLiteDatabase ParkingDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        edtName=findViewById(R.id.edtName);
        edtPhone=findViewById(R.id.edtPhone);
        edtEmail=findViewById(R.id.edtEmail);

        btnAddContact=findViewById(R.id.btnAddContact);
        btnAddContact.setOnClickListener(this);

        dbHelper=new DBHelper(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==btnAddContact.getId())
        {
            String name=edtName.getText().toString();
            String phone=edtPhone.getText().toString();
            String email=edtEmail.getText().toString();

            if (phone.isEmpty()) {
                Toast.makeText(this,"phone number must be filled",Toast.LENGTH_LONG).show();
            } else {
                insertData();
                Toast.makeText(this,"Service provider added successfully",Toast.LENGTH_LONG).show();
            }


            //         Intent homeIntent=new Intent(this,HomeActivity.class);
//            startActivity(homeIntent);
        }
    }
    private void insertData()
    {
        String name=edtName.getText().toString();
        String phone=edtPhone.getText().toString();
        String email=edtEmail.getText().toString();

        ContentValues cv=new ContentValues();
        cv.put("Name",name);
        cv.put("Phone",phone);
        cv.put("Email",email);
        try
        {

            ParkingDB=dbHelper.getWritableDatabase();
            ParkingDB.insert("contact",null,cv);
            // Log.v(ServiceProviderActivity,"service provider added");

        }catch (Exception e)
        {
            // Log.e(ServiceProviderActivity, e.getMessage());
        }
        ParkingDB.close();
    }
}

package com.example.macstudent.login;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddContactActivity extends AppCompatActivity implements View.OnClickListener {
EditText edtName;
EditText edtPhone;
EditText edtEmail;
EditText edtId;
DBHelper dbHelper;
Button btnAddContact;
String name,phone,email,id;
    SQLiteDatabase ParkingDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        edtName=findViewById(R.id.edtName);
        edtPhone=findViewById(R.id.edtPhone);
        edtEmail=findViewById(R.id.edtEmail);
        edtId=findViewById(R.id.edtId);

        btnAddContact=findViewById(R.id.btnAddContact);
        btnAddContact.setOnClickListener(this);

        dbHelper=new DBHelper(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==btnAddContact.getId())
        {
             name=edtName.getText().toString();
             phone=edtPhone.getText().toString();
             email=edtEmail.getText().toString();
            id=edtId.getText().toString();

            if (phone.isEmpty()) {
                Toast.makeText(this,"phone number must be filled",Toast.LENGTH_LONG).show();
            } else {
                insertData();
                Toast.makeText(this,"emergency contact added successfully",Toast.LENGTH_LONG).show();
            }
             Intent intent=new Intent(this,HomeActivity.class);

            //         Intent homeIntent=new Intent(this,HomeActivity.class);
//            startActivity(homeIntent);
        }
    }
    private void insertData()
    {
         name=edtName.getText().toString();
         phone=edtPhone.getText().toString();
         email=edtEmail.getText().toString();
        id=edtId.getText().toString();

        ContentValues cv=new ContentValues();
        cv.put("Name",name);
        cv.put("Phone",phone);
        cv.put("Email",email);
        cv.put("Id",id);
        try
        {

            ParkingDB=dbHelper.getWritableDatabase();
            ParkingDB.insert("Contact",null,cv);


        }catch (Exception e)
        {

        }
        ParkingDB.close();
    }
}

package com.example.macstudent.login;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity {
    DBHelper dbHelper = new DBHelper(this);
    SQLiteDatabase db;
    private ArrayList<String> Id = new ArrayList<String>();
    private ArrayList<String> Name = new ArrayList<String>();
    private ArrayList<String> Phone = new ArrayList<String>();
    private ArrayList<String> Email = new ArrayList<String>();
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);


            lv = (ListView) findViewById(R.id.listContact);
        }
        @Override
        protected void onResume() {
            displayData();
            super.onResume();
        }
        private void displayData() {
            db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM  Contact",null);
            Id.clear();
            Name.clear();
            Phone.clear();
            Email.clear();
            if (cursor.moveToFirst()) {
                do {
                    Id.add(cursor.getString(cursor.getColumnIndex("Id")));
                    Name.add(cursor.getString(cursor.getColumnIndex("Name")));
                    Phone.add(cursor.getString(cursor.getColumnIndex("Phone")));
                    Email.add(cursor.getString(cursor.getColumnIndex("Email")));
                } while (cursor.moveToNext());
            }
            ViewAdapter va = new ViewAdapter(this,Id, Name,Phone,Email);
            lv.setAdapter(va);
            //code to set adapter to populate list
            cursor.close();
        }

    }



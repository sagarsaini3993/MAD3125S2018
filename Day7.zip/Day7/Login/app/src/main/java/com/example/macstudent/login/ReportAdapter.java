package com.example.macstudent.login;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

public class ReportAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    String[] carPlates = {"ASDF123","QWER123","ASDF123"};
    String[] lots = {"A","B","C"};
    String[] spots= {"1","41","23"};
    String[] dateTime = {"12-12-2018 12:12:12","12-12-2018 13:12:12","12-12-2018 10:10:10"};
    String[] amounts = {"10","20","30"};

    ReportAdapter(Context context) {
        this.context = context;
        inflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return carPlates.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        convertView=inflater.inflate(R.layout.list_report_form, null);

        TextView txtDateTime = convertView.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);

        TextView txtCarPlate = convertView.findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(carPlates[position]);

        TextView txtAmount = convertView.findViewById(R.id.txtAmount);
        txtAmount.setText("$" + amounts[position]);

        TextView txtLot = convertView.findViewById(R.id.txtLot);
        txtLot.setText("Lot" + lots[position]);

        TextView txtSpot = convertView.findViewById(R.id.txtSpot);
        txtSpot.setText("Spot" + spots[position]);

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "item " +position+ " selected", Toast.LENGTH_LONG).show();
            }
        });


        return convertView;
    }
}

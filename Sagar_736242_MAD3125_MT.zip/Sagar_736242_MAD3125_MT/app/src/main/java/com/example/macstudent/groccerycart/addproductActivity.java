package com.example.macstudent.groccerycart;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AndroidException;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class addproductActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Spinner spnCategory, spnNames, spnManufacturerComp;
    EditText edtPrice, edtQuantity;

    String[] arrCat = {"Stationery"};
    String[] arrNames = {"Pen", "Pencil", "Eraser", "Sharpner", "Scale"};
    String[] arrManufacturerComp = {"Apsara"};
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addproduct);

        spnCategory = findViewById(R.id.spnCategory);
        ArrayAdapter<String> adp1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrCat);
        spnCategory.setAdapter(adp1);
        spnCategory.setOnItemSelectedListener(this);

        spnNames = findViewById(R.id.spnProductName);
        ArrayAdapter<String> adp2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrNames);
        spnNames.setAdapter(adp2);
        spnNames.setOnItemSelectedListener(this);

        spnManufacturerComp = findViewById(R.id.spnManufacturerComp);
        ArrayAdapter<String> adp3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrManufacturerComp);
        spnManufacturerComp.setAdapter(adp3);
        spnManufacturerComp.setOnItemSelectedListener(this);

        edtPrice = findViewById(R.id.edtPricePerUnit);
//        edtPrice.getText().toString();

        edtQuantity = findViewById(R.id.edtPricePerUnit);
//        edtQuantity.getText().toString();

        btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);


        Intent intent = new Intent(addproductActivity.this, viewOrderActivity.class);




    }


    @Override
    public void onClick(View v) {

        if (btnSubmit.getId() == v.getId()) {
            SharedPreferences sp = getSharedPreferences("com.example.macstudent.groccerycart.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putInt("Price", Integer.parseInt(edtPrice.getText().toString()));
            edit.putInt("Quantity", Integer.parseInt(edtQuantity.getText().toString()));

            edit.commit();

            Toast.makeText(this, "Data submitted succesfully", Toast.LENGTH_LONG).show();

        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
